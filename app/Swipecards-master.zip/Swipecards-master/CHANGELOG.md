#### 1.0.9
- Merged pull requests: Fixes with ViewPager conflict, Picasso and IllagalException erors